public class Node_splay {
    int data;
    Node_splay rodic;
    Node_splay lavy;
    Node_splay pravy;

    String text;

    Node_splay(int data, String text)
    {
        this.data=data;
        this.text=text;
    }
}
