public class Node_hash {

        int kluc;
        String text;
        Node_hash kamos=null;

        public Node_hash(int kluc, String text){
            this.kluc=kluc;
            this.text=text;
        }
}
