public class Node_avl {
    int data;
    int vyska = 0;
    Node_avl lavy;
    Node_avl pravy;

    String text;

    Node_avl(int data, String text)
    {
        this.data=data;
        this.text=text;
    }


}
